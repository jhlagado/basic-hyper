import { LitElement, html } from '@polymer/lit-element';
import { render } from 'lit-html';



class NabcTabs1 extends LitElement {


    // Public property API that triggers re-render (synced with attributes)
    static get properties() {
        return {

        }
    }


    constructor() {
        super()


    }
    connectedCallback() {
        super.connectedCallback();

        

    }



    _render({ }) {
        return html`      
        <div>
        <slot></slot>
        </div>
       `;
    }

}
customElements.define('nabc-tabs1', NabcTabs);