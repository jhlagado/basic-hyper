import { LitElement, html } from '@polymer/lit-element';
import { render } from 'lit-html';

const template = document.createElement('template');

class Tab extends LitElement {

  
    // Public property API that triggers re-render (synced with attributes)
    static get properties() {
        return {

        }
    }


    constructor() {
        super()
     
    }
    connectedCallback() {
        super.connectedCallback();
      
    }

   

    _render({ }) {
        return html`  
       
       
        inner component
      
       `;
    }

}
customElements.define('nabc-tab', Tab);