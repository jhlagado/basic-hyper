import { LitElement, html } from '@polymer/lit-element';
import { render } from 'lit-html';


class NabcPanel extends LitElement {
   
    static get properties() {
        return {
        }
    }

    constructor() {
        super()


    }

    connectedCallback() {
        super.connectedCallback();
    }

    _render({ title }) {
        return html`   
        <style>
        :host div{         
            padding: 6px 12px;
            border: 1px solid #ccc;
            border-top: none;
        }     
        :host([aria-hidden]){         
           display:none
        }     

        </style>

        <div>
        <slot></slot>
        </div>       
       `;
    }

}
customElements.define('nabc-panel', NabcPanel);