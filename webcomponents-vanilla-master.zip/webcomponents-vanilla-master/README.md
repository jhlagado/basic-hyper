# webcomponents-vanilla

#Get started
- step 1  npm install
- step 2  polymer serve --open 