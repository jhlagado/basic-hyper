import { LitElement, html } from '@polymer/lit-element';

class MyElement extends LitElement {

    // Public property API that triggers re-render (synced with attributes)
    static get properties() {
      return {
        foo: String,
        whales: Number
      }
    }
  
    constructor() {
      super();
      this.foo = 'foo';
   
      this.addEventListener('click', async (e) => {
        this.whales++;
       // await this.renderComplete;
       this.dispatchEvent(new CustomEvent('whales', {detail: {whales: this.whales}}))
      });
      document.querySelector("my-element").addEventListener("whales", function(e) { console.log(e); });
    }
  
    // Render method should return a `TemplateResult` using the provided lit-html `html` tag function
    _render({foo, whales}) {
      return html`
        <style>
          :host {
            display: block;
          }
          :host([hidden]) {
            display: none;
          }
          ::slotted(div) {
            margin: 0;
            font-weight: 300;d
            color: green;
          }
          
         
          .some{
              color:red
          }
        </style>
        <h4>Foo: ${foo}</h4>
        <div class="some">whales: ${'🐳'.repeat(10)} <slot></slot></div>
       
      `;
    }
  
  }
  customElements.define('my-element', MyElement);