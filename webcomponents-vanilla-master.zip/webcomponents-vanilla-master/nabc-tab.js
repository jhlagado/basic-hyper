import { LitElement, html } from '@polymer/lit-element';
import { render } from 'lit-html';



class NabcTab extends LitElement {

    constructor() {
        super()
    }  
  
   
    static get properties() {
        return {
            title: {
                type: String,
                attrName: 'title'
            },
            selected: {
                type: Boolean,
                attrName: 'selected'
            }
        }
    }

    set selected(value) {
        value = Boolean(value);
        if (value)
            this.setAttribute('selected', '');
        else
            this.removeAttribute('selected');

        this.requestRender();
    }

    get selected() {
        return this.hasAttribute('selected');
    }


    connectedCallback() {
        super.connectedCallback();
    }


    _render({ title, selected }) {
        return html`   
        <style>
        :host{
            overflow: hidden;
            border: 1px solid #ccc;
            background-color: #f1f1f1;
            display: inline-flex;
        }
        :host([selected]){
            background-color: #ccc;
        }      
        
        :host button {
            background-color: inherit;
            float: left;
            border: none;
            outline: none;
            cursor: pointer;
            padding: 14px 16px;
            transition: 0.3s;
            font-size: 17px;
        }

        :host button:hover {
            background-color: #ddd;
        }   
        </style>
     
        <button>${this.title}</button>     
       `;
    }

}
customElements.define('nabc-tab', NabcTab);