import { LitElement, html } from '@polymer/lit-element';
import { render } from 'lit-html';



class NabcTabs extends LitElement {


    static get properties() {
        return {
        }
    }


    constructor() {
        super()
    }

    connectedCallback() {
        super.connectedCallback();

        this.tabs = this._allTabs();
        this.panels = this._allPanels();

        this._onTabClick = this._onTabClick.bind(this)

        for (let [i, tab] of this.tabs.entries()) {
            tab.setAttribute('role', 'tablist');
            tab.setAttribute('index', i);
            tab.setAttribute('slot', 'tabs');
            tab.addEventListener('click', this._onTabClick);
        }

        for (let [i, panel] of this.panels.entries()) {
            panel.setAttribute('role', 'panel');
            panel.setAttribute('index', i);
            panel.setAttribute('slot', 'panels');

        }

      
        const selectedTab = this._findFirstSelectedTab();
        this._selectPanel(selectedTab);
    }

    _findFirstSelectedTab() {
        let selectedIdx;
        for (let [i, tab] of this.tabs.entries()) {         
            if (tab.hasAttribute('selected')) {
                selectedIdx = i;
            }
        }
        return selectedIdx;
    }

    _allTabs() {
        return this.querySelectorAll('nabc-tab');
    }

    _allPanels() {
        return this.querySelectorAll('nabc-panel');
    }

    _onTabClick(event) {
       const currentTabIdx= this._selectTab(event.target);
       var myEvent = new CustomEvent("currentTab", {
        detail: {
            username: "davidwalsh"
        },
        bubbles: true,
        composed: true
    });
        this.dispatchEvent(myEvent);
    }

    _resetTabs() {
        const tabs = this.tabs;      
        tabs.forEach(tab => tab.selected = false);    
    }

    _resetPanels() {   
        const panels = this.panels;       
        panels.forEach(panel => panel.hidden = true);
    }

    _selectTab(tab) {
        this._resetTabs();
        tab.selected = true;
        tab.focus();


        let currentTabIdx = this._getTabIndex(tab);
        this._selectPanel(currentTabIdx);
        return currentTabIdx;
    }

    _getTabIndex(tab) {
        return tab.getAttribute('index');
    }

    _selectPanel(index) {
        this._resetPanels();
        let panel = this.querySelector(`nabc-panel[index="${index}"]`);
        panel.hidden = false;
    }

    _render({ }) {
        return html`      
        <div>
        <slot name="tabs"></slot>        
        <slot name="panels"></slot>
        </div>
       `;
    }

}
customElements.define('nabc-tabs', NabcTabs);