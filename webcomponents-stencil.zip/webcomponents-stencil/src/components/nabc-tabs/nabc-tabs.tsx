import { Component, Prop, Element, Listen } from '@stencil/core';



@Component({
    tag: 'nabc-tabs',
    styleUrl: 'nabc-tabs.scss',
    shadow: true
})
export class NabcTabs {

    childTabs: any = [];
    childPanels: any = [];

    @Prop() title: string;
   
    @Element() host: HTMLElement;

    componentDidLoad() {

        this.childTabs = this.getAllTabElements();
        this.childPanels = this.getPanelElements();

     
        this.childTabs.forEach((tab,i)=>{ tab.setAttribute('id', i);});
        this.childPanels.forEach((panel,i)=>{ panel.setAttribute('id', i);});

        this.selectPanelByTabId(this.findFirstSelectedTab());
    }

    findFirstSelectedTab() {     
        let currentSelectedTab:number;
        
        this.childTabs.forEach((tab,i)=>{ tab.activated ? currentSelectedTab = i : 0});
              
        return currentSelectedTab;
    }
    resetTabs() {
        const tabs = this.childTabs;
        tabs.forEach(tab => tab.activated = false);
    }

    resetPanels() {
        const panels = this.childPanels;
        panels.forEach(panel => panel.activated = true);
    }

    getAllTabElements() {
        return Array.from(this.host.querySelectorAll('nabc-tab')) as any[];
    }

    getPanelElements() {
        return Array.from(this.host.querySelectorAll('nabc-panel')) as any[];
    }

    @Listen('onSelect')
    onSelectedTab(event: CustomEvent) {
        this.resetTabs();
        this.resetPanels();

        const selectedTab: any = event.target;
        selectedTab.activated = true;

        this.selectPanelByTabId(selectedTab.id);
    }

    selectPanelByTabId(tabId) {       
        let panel: any = this.host.querySelector(`nabc-panel[id="${tabId}"]`);
        panel.activated = false;
    }


    render() {
        return (
            <div>
                <div class="tab">
                    <slot name="tabs"></slot>
                </div>
                <div>
                    <slot name="panels"></slot>
                </div>
            </div>
        );
    }
}
