import { Component, Prop, Event, EventEmitter, Element } from '@stencil/core';



@Component({
  tag: 'nabc-tab',
  styleUrl: 'nabc-tab.scss',
  shadow: true
})
export class NabcTab {
  @Element() host: HTMLElement;

  @Prop() title: string;
  @Prop() id: string;
  @Prop() activated: boolean;

  @Event() onSelect: EventEmitter;


  onClick() {
    this.onSelect.emit();
  }

  render() {
    return (
      <button class={this.activated ? 'active' : ''} onClick={this.onClick.bind(this)}>{this.title}</button>
    );
  }
}
