import { Component, Prop, Element } from '@stencil/core';


@Component({
  tag: 'nabc-panel',
  styleUrl: 'nabc-panel.scss',
  shadow: true
})
export class NabcPanel {
  @Element() host: HTMLElement;
  @Prop() id: string;
  @Prop() activated: boolean=true;

  render() {
    const classes = {
      'tabcontent': true,
      'tabcontent hidden': this.activated
    };
    return (
      <div class={classes}>
        <slot></slot>
      </div>
    );
  }
}
